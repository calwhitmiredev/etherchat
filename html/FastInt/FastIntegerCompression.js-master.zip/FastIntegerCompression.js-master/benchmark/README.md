Performance benchmarks
===

You should have node.js and npm installed to run
these benchmarks. It assumes a recent version of node.js (4.0.0 or better).

npm install benchmark
npm install sizeof
nodejs test.js
